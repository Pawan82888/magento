<?php

namespace Cloudbanking\Cloudbanking\Model;
use Magento\Sales\Model\Order\Payment\Transaction;
use Omnipay\Common\CreditCard;
use Omnipay\Omnipay;
class PaymentModel extends \Magento\Payment\Model\Method\Cc
{
    const CODE = 'cloudbanking';

    protected $_code = self::CODE;

    protected $_canUseCheckout = true;
    protected $_canUseInternal = false;
    protected $_canUseForMultishipping = false;
    protected $_canSaveCc = false;
    protected $_isInitializeNeeded = true;

    protected $_minAmount = 0.5;
    protected $_supportedCurrencyCodes = ['EUR', 'USD', 'GBP'];
    protected $_canAuthorize = true;
    protected $_canCapture = true;
    protected $_canRefund = true; 

    /**
     * @var $_client Cloudbanking\Client SDK client
     */
    // private $_client;

    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        \Magento\Payment\Helper\Data $paymentData,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Payment\Model\Method\Logger $logger,
        \Magento\Framework\Module\ModuleListInterface $moduleList,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Sales\Model\Order $order,
        \Magento\Sales\Model\Order\CreditmemoFactory $creditmemoFactory,
        \Magento\Sales\Model\Order\Invoice $Invoice,
        \Magento\Sales\Model\Service\CreditmemoService $CreditmemoService,
        array $data = []
    ) {
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $logger,
            $moduleList,
            $localeDate,
            null,
            null,
            $data
        );
        $this->order = $order;
        $this->creditmemoFactory = $creditmemoFactory;
        $this->CreditmemoService = $CreditmemoService;
        $this->Invoice = $Invoice;
        $this->_objectManager = $objectManager;
        $this->_messageManager = $messageManager;
        $this->_storeManager = $storeManager;
    }

    /**
     * Method that will be executed instead of authorize or capture
     * if flag isInitializeNeeded set to true
     *
     * @param string $paymentAction
     * @param object $stateObject
     *
     * @return $this
     */
    public function initialize($paymentAction, $stateObject)
    {
        $this->_log('called ' . __METHOD__);

        parent::initialize($paymentAction, $stateObject);

        if ($paymentAction != 'sale') {
            $this->_log('Wrong payment action. Only sale is allowed.');
            $this->_setMessage(__('Internal error occurred. Please contact support.'), 'error');
        }

        $orderModel = $this->_getOrderModel();
        $state = $orderModel::STATE_PENDING_PAYMENT;

        // Set the default state of a new order.
        $stateObject->setState($state);
        $stateObject->setStatus($state);
        $stateObject->setIsNotified(false);
        $this->_log('order status changed to pending payment');

        // Make initial payment attempt
        try {
            $this->_makePayment();
        } catch (Exception $e) {
            $this->_log($e->getMessage());
            $this->_setMessage(__('Internal error occurred. Please contact support.'), 'error');
        }

        return $this;
    }

    protected function _makePayment()
    {
        $this->_log('called ' . __METHOD__);
       
        // Process payment
        $payment = $this->getInfoInstance();
        $order = $payment->getOrder();
        
        $order->save();
  
        $amount = $order->getTotalDue();

        // Validate minimum sale amount
        if ($amount < $this->_minAmount) {
            $this->_setMessage(__('Invalid order amount. Minimum amount: 0.50!'), 'error');
        }

        $holder = mb_substr(sprintf(
            '%s %s',
            $order->getBillingAddress()->getData('firstname'),
            $order->getBillingAddress()->getData('lastname')
        ), 0, 32);
           $card = $this->createCard($payment);
           $gateway = $this->gateway_instance();
           $gateway->setParameter('card',$card);
            $createCardRequest = $gateway->createCard();
            $cardCreateResponse = $createCardRequest->send();
            if($cardCreateResponse->isSuccessful()){
                //transaction
                    $cardToken = $cardCreateResponse->getToken();
                    $total_amount=  $amount;
                    $transaction = $gateway->purchase(array(
                        'cardReference' => $cardToken,
                        'amount' =>$total_amount,
                        'transactionId'=>$order->getRealOrderId()
                    ));

                $response = $transaction->send();
               try { 
                    if($response->isSuccessful()){
                        if($response->getTransactionReference()){
                        $authModel = $this->_getAuthModel();
                        $authModel->cleanup();
                        $banktransactionid = $response->getTransactionReference(); 
                        $authModel->setOrderId($order->getId());
                       
                        $payment->setTransactionId($banktransactionid);
                        $payment->setParentTransactionId($banktransactionid);
                        $token=$response->getCardReference();
                        $payment->setCcStatusDescription($token);
                        $payment->setIsTransactionClosed(false);
                        $this->_createInvoice($order,$banktransactionid, $total_amount); 
                        $authModel->setRealOrderId($order->getRealOrderId());
                        $authModel->setPaymentId($banktransactionid);
                        $authModel->setSuccess(true);
                        
                        }else{
                            $authModel->setFailure(true);
                        }
                    } 
                }catch (\Exception $e) {
                    $this->_log($e->getMessage());
                    $this->_setMessage(__('Unexpected error occurred. Please contact support.'), 'error');
                 }
            }

    }

    /**
     * Finalize payment after 3-D security verification
     *
     * @param string $paymentId payment id received from Cloudbanking
     * @param string $pares payer authentication response received from ACS
     * @return boolean
     */


    public function finalize($paymentId, $pares)
    {
        $this->_log('called ' . __METHOD__);

        $method = new Payment\Finalize($paymentId, $pares);

        try {
            $result = $this->_call($method);
        } catch (\Exception $e) {
            $this->_log($e->getMessage());
            $this->_setMessage(__('Unexpected error occurred. Please contact support.'), 'error');
        }

        return $result && $result->isApproved();
    }

    /**
     * Check method for processing with base currency
     *
     * @param string $currencyCode
     * @return bool
     */
    public function canUseForCurrency($currencyCode)
    {
        $this->_log('called ' . __METHOD__);

        if (!in_array($currencyCode, $this->_supportedCurrencyCodes)) {
            return false;
        }
        return true;
    }


    private function _setMessage($message, $type)
    {
        switch ($type) {
            case 'notice':
                $this->_messageManager->addNoticeMessage($message);
                break;
            case 'success':
                $this->_messageManager->addSuccessMessage($message);
                break;
            case 'warning':
                $this->_messageManager->addWarningMessage($message);
                break;
            case 'error':
                $this->_messageManager->addErrorMessage($message);
                break;
        }
    }

    private function _log($message)
    {
        $this->_logger->info('Cloudbanking Gateway: ' . $message);
    }

    private function _getAuthModel()
    {
        return $this->_objectManager->create('Cloudbanking\Cloudbanking\Model\AuthModel');
    }

    private function _getOrderModel()
    {
        return $this->_objectManager->create('Magento\Sales\Model\Order');
    }
    public function createCard($payment){
        
        $card = new CreditCard();
        
        $order = $payment->getOrder();

        $card->setNumber($payment->_data['cc_number']);
        $card->setExpiryYear((int)$payment->_data['cc_exp_year']);
        $card->setExpiryMonth((int)$payment->_data['cc_exp_month']);
        $card->setCvv($payment->_data['cc_cid']);
        $card->setEmail($order->getCustomerEmail());
          
        $billing = $order->getBillingAddress();

        $card->setBillingFirstName($billing->getFirstname());
        $card->setBillingLastName($billing->getLastname());
        $card->setBillingAddress1($billing->getStreetLine(1));
        $card->setBillingAddress2($billing->getStreetLine(1));
        $card->setBillingCity($billing->getCity());
        $card->setBillingCountry($billing->getCountry());
        $card->setBillingState($billing->getRegion());
        $card->setBillingPhone($billing->getTelephone());
        $card->setBillingCompany($billing->getCompany());
        $card->setBillingPostcode($billing->getPostcode());
        
        $shipping = $order->getShippingAddress();

        $card->setShippingFirstName($shipping->getFirstname());
        $card->setShippingLastName($shipping->getLastname());
        $card->setShippingAddress1($shipping->getStreetLine(1));
        $card->setShippingCity($shipping->getCity());
        $card->setShippingCountry($shipping->getCountry());
        $card->setShippingState($shipping->getRegion());
        $card->setShippingCompany($shipping->getCompany());
        $card->setShippingPostcode($shipping->getPostcode());
        $card->setShippingPhone($shipping->getTelephone());

        return $card;
        
    }

    public function gateway_instance(){
        $gateway = Omnipay::create('CloudBanking');

        $gateway->setAuthKey($this->getConfigData('auth_key'));
        $gateway->setApiVersion($this->getConfigData('api_version'));
        $gateway->setCustomerReference($this->getConfigData('customer_id'));

        return $gateway;
    }
    /**
     * called if refunding
     */
     public function refund(\Magento\Payment\Model\InfoInterface $payment, $amount)
     {
         if (!$this->canRefund()) {
             throw new \Magento\Framework\Exception\LocalizedException(__('The refund action is not available.'));
         }
         $banktransaction=$payment->getTransactionId();
         $int = $banktransaction;
         $banktransaction_id = intval(preg_replace('/[^0-9]+/', '', $int), 10);
        
         $cardtoken=$payment->getTransactionAdditionalInfo();
         $cardtoken2=$payment->getCcStatusDescription();
         $gateway = $this->gateway_instance();
         $refundRequest = $gateway->refund(array(	  
           'cardReference' 		=> $cardtoken2,
           'transactionReference'	=>  $banktransaction_id,
         ));
         
         $refundResponse = $refundRequest->send();
         if ($refundResponse->isSuccessful()) {
         return $this;
         }
         else{
             return false;
         }
         
        
     }
 
    protected function _createInvoice($order ,$banktransactionid , $total_amount)
    {
        $this->_log('called ' . __METHOD__);

        if (!$order->canInvoice()) {
            return false;
        }
        $invoice = $order->prepareInvoice();
        $invoice->setRequestedCaptureCase(\Magento\Sales\Model\Order\Invoice::CAPTURE_ONLINE);
        $invoice->setTransactionId($banktransactionid);
        $invoice->register();
        if ($invoice->canCapture()) {
            $invoice->capture();
            
        }
       
        $creditmemo =$this->creditmemoFactory->createByInvoice($invoice);
        $creditmemo->setShippingAmount(0);
        $creditmemo->setGrandTotal( $total_amount);
        $creditmemo->setRefundRequested(true);
        $creditmemo->setOfflineRequested(false);
        $creditmemo->setPaymentRefundDisallowed(true);
        $invoice->save();
       
        return $invoice;
    }

}
