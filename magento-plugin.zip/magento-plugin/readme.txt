Cloudbanking Payment Module for Magento 2 CE

This is a Payment Module for Magento 2 Community Edition, that gives you the ability to process payments through payment service providers running on Cloudbanking platform.

Requirements

Magento 2.1.9
cloudbanking/omnipay-cloudbanking

Note: this module has been tested only with Magento 2.1.9 Community Edition, it may not work as intended with Magento 2 Enterprise Edition

Installation (composer)

Install Composer - Composer Download Instructions


$ composer require cloudbanking/cloudbanking
Enable Payment Module

$ php bin/magento module:enable Cloudbanking_Cloudbanking
$ php bin/magento setup:upgrade
Deploy Magento Static Content (Execute If needed)

$ php bin/magento setup:static-content:deploy
Installation (manual)


$ php bin/magento module:enable Cloudbanking_Cloudbanking --clear-static-content
$ php bin/magento setup:upgrade
Deploy Magento Static Content (Execute If needed)

$ php bin/magento setup:static-content:deploy
Configuration

Login inside the Admin Panel and go to Stores -> Configuration -> Sales -> Payment Methods
If the Payment Module Panel Cloudbanking is not visible in the list of available Payment Methods, go to System -> Cache Management and clear Magento Cache by clicking on Flush Magento Cache
Go back to Payment Methods and click the button Configure under the payment method Cloudbanking Checkout or Cloudbanking Direct to expand the available settings
Set Enabled to Yes, set the correct credentials, select your prefered transaction types and additional settings and click Save config
Configure Magento over secured HTTPS Connection

This configuration is needed for Cloudbanking Direct Method to be usable.

Auth key 361
api version:2 
customer id:mgento
Test card details

cardnumber=4444333322221111
cardexpiry=10/21
cardcvv=123
cardnam=John Smith